Hi Again!!
So you want to solve this challenge. Nice!

Robin created an encryption algorithm and give equivalent python code "cipher.py" to Batman with cipherText to decode. Batman decode it in 1 hour. 
Can you beat batman?
Robin bet that you will not even crack it.


Task: you need to write decipher code and decode cipherText.txt for flag
