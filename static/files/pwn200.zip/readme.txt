access to machine with following command

$ ssh guest@192.168.122.206

install openssh and ssh in your machine first then run above command

password is 'iamguest123'

don't forget to read readme.txt there :-)
